package com.example.firsttest.firsttest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PartTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part_two);

        Button GoBackButton = (Button) findViewById(R.id.GoBackButton);
        GoBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Start = new Intent(getApplicationContext(), com.example.firsttest.firsttest.PartOne.class);
                startActivity(Start);

            }
        });


        // Save Button Button
        Button SaveButton = (Button) findViewById(R.id.SaveButton);
        SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tv1 = (TextView) findViewById(R.id.TextFieldOne);
                tv1.setText("Save Button Pressed");

            }
        });

        // Clear Button
        Button ClearButton= (Button) findViewById(R.id.ClearButton);
        ClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tv1 = (TextView) findViewById(R.id.TextFieldOne);
                tv1.setText("Clear Button Pressed");

            }
        });

    }
}
