package com.example.firsttest.firsttest;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class PartOne extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part_one);

        Button PartTwoBtn = (Button) findViewById(R.id.PartTwoButton);
        PartTwoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Start = new Intent(getApplicationContext(), com.example.firsttest.firsttest.PartTwo.class);

                // part two code here.

                startActivity(Start);
            }
        });






    }

    public void ButtonFunction(View view) {

        EditText TextFieldOne = (EditText) findViewById(R.id.TextFieldOne);
        Button ChangeColorBtn = (Button) findViewById(R.id.ChangeColorBtn);

        ChangeColorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView TextFieldOne = (TextView) findViewById(R.id.TextFieldOne);
                Random rColor = new Random();

                 int r = rColor.nextInt(255);
                int g = rColor.nextInt(255);
                int b = rColor.nextInt(255);

                String rHex = Integer.toHexString(r);
                String gHex = Integer.toHexString(g);
                String bHex = Integer.toHexString(b);

                TextFieldOne.setTextColor(Color.rgb(r,g,b));
                TextFieldOne.setText("COLOR: "+ r + "r, " + g + "g, " + b + "b, " + "#" + rHex + gHex + bHex);

            }
        });



    }




}